# montage skills（CSV 清单）

`skills.csv` 是全部 14 条能力的机器可读清单：命令、作用、关键参数、适用场景、实现状态。

## 列说明

| 列 | 含义 |
|---|---|
| `id` | 编号 S01–S14 |
| `name` | 命令名 |
| `category` | 分类 |
| `command` | 可直接运行的完整命令 |
| `what_it_does` | 做什么 |
| `key_params` | 关键参数 |
| `when_to_use` | 什么时候用 |
| `status` | 实现状态（全部为"已实现并运行"） |

## 用法

Excel / Numbers / Google Sheets 直接打开，或：

```bash
python3 -c "import csv;[print(r['id'],r['name'],'—',r['when_to_use']) for r in csv.DictReader(open('skills.csv'))]"
```

需要完整可运行的工具请用 `valorant-montage-v1.zip`。
