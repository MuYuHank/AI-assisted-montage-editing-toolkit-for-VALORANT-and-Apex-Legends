# VALORANT 击杀集锦 · Claude 开发交付包 v1

这是中文开发规格，不是已实现代码仓库。用户希望参考高质量击杀集锦制作工作流；不是复制视频、音乐或保证热门。所有实现技术是建议默认值，开发前请确认素材、目标画幅、片长、音乐授权与运行机器。

## 开始顺序
1. 阅读 [需求](docs/01-requirements.md) 与 [参考证据](docs/02-reference-evidence.md)。
2. 把 [CLAUDE_START.md](CLAUDE_START.md) 全文交给 Claude，并附整个包。
3. Claude 先实现 T01–T03、跑合成素材；再用你拥有的实录做 T04–T06。
4. 预览、人工批准后才导出发布版；本包没有发布功能。

## 文件导航
- [架构与算法](docs/03-architecture.md)
- [分包任务及未来验收](docs/04-tasks.md)
- [测试计划](docs/05-testing.md)
- [可行性与风险](docs/06-feasibility.md)
- [数据语义](docs/07-contracts.md)
- [JSON Schema](schemas/edit-plan.schema.json)、[有效示例](examples/edit-plan.example.json)、[配置示例](config/defaults.json)
- [实际规格验证记录](VALIDATION.md)、[文件清单](MANIFEST.json)

包内不包含参考视频、商业音乐、用户素材或应用实现。示例路径是虚构的占位文件。所列 pytest/CLI 命令是未来交付验收目标，不代表现已可运行。当前仅验证文档链接、JSON Schema、示例时序等规格层面。
