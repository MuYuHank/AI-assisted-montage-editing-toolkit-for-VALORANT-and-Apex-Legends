# 07 数据契约（起始规格，不是已实现 API）

schema 使用 JSON Schema Draft 2020-12。未知字段拒绝；id 全局唯一、引用/时序/预算/文件存在性需要语义校验，不能仅靠 JSON Schema。

source.duration_s 来自 ffprobe，不相信用户填值；示例为虚构时长。source.path 只能是素材根内相对路径。markers.time_s 为源 PTS 秒，origin=human。included marker 必须在对应 clip 内且有 anchor；excluded 列出原因。一个标记不可重复出现。marker 源与 clip 源一致，所有 clips 按 output_start 连续排序、源区间合法。duration_s 为全部 clip 输出时长之和，最大不超过 target+tolerance。低于 target−tolerance 给警告。

anchors.output_time_s 必须按 docs/03 的公式计算；源与输出均用秒。示例均为 1x：k1 输出 1.5s，k2 输出 3.8s，总长 4.6s；不足 30s 目标，应产生短片警告。P1 单独算术测试：源 [10,15]、rate=1.25、输出起点 2，源 12.5 的输出锚点=4s，输出结束=6s。此算术不等于允许对击杀核心加速。

music 可为 null；有音乐时 rights_confirmed=true、source_in_s≥0、output_start_s≥0、beat_times_s 递增且去重。节拍均相对音乐源；需实际 probe 检查音乐长度。schema 的配置项不是授权证明，用户仍需实际拥有权利。

配置 JSON 是设计默认，不是可运行程序配置。schema/example 通过仅证明结构和所列算术约束，不证明视觉效果或应用存在。
