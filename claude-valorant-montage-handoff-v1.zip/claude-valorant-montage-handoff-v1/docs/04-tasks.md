# 04 逐项实现交接

以下路径是 Claude 应在新代码仓库创建的路径，不是本包已有代码。函数为建议契约；每条命令都是未来验收，当前未执行。函数收 JSON-compatible dict / Path，返回 dict 或 Path；验证失败抛 ValueError，外部进程失败抛 RuntimeError。依赖关系为有向无环链。

|任务|依赖|预期新增文件与函数|未来验收命令|
|---|---|---|---|
|T01 环境与媒体探测|无|pyproject.toml；src/montage/cli.py: main(argv:list[str]\|None)->int；src/montage/probe.py: probe_media(path:Path)->dict；tests/test_probe.py|`python -m pip install -e '.[test]'`；`python -m montage.cli doctor`；`pytest -q tests/test_probe.py`|
|T02 契约、路径与标记校验|T01|src/montage/contracts.py: validate_plan(plan:dict)->None, validate_markers(markers:dict,media:dict)->None；src/montage/paths.py: resolve_asset(root:Path,relative:str)->Path；tests/test_contracts.py|`pytest -q tests/test_contracts.py`|
|T03 确定性规划|T02|src/montage/selection.py: build_groups(markers:list[dict],sources:dict,cfg:dict)->list[dict], select_groups(groups:list[dict],cfg:dict)->list[dict]；src/montage/timeline.py: map_source_time(clip:dict,t:float)->float；src/montage/planner.py: build_plan(sources:list[dict],markers:list[dict],cfg:dict)->dict；tests/test_selection.py, tests/test_timeline.py|`pytest -q tests/test_selection.py tests/test_timeline.py`|
|T04 保守渲染|T03|src/montage/render.py: render_preview(plan:dict,asset_root:Path,workdir:Path)->Path；tests/test_render.py；tests/make_fixtures.py|`python tests/make_fixtures.py --out tests/fixtures/generated`；`pytest -q tests/test_render.py`|
|T05 预览检查、批准与导出|T04|src/montage/inspect.py: inspect_preview(plan:dict,preview:Path)->dict；src/montage/approval.py: approve(plan:Path,preview:Path,config:Path,output:Path)->dict, export_approved(approval:dict,destination:Path)->Path；tests/test_approval.py|`pytest -q tests/test_approval.py`|
|T06 CLI 与自有素材验收|T05|扩展 src/montage/cli.py；src/montage/__init__.py；tests/test_cli.py；docs/operator-guide.md|`pytest -q tests/test_cli.py`；`python -m montage.cli --help`；按下方端到端命令运行|
|T07 可选速度/人工节拍|T06|src/montage/beats.py: snap_boundaries(plan:dict,beats:list[float],cfg:dict)->dict；扩展 timeline.py/render.py；tests/test_beats.py|`pytest -q tests/test_beats.py tests/test_timeline.py tests/test_render.py`|

T01 必须检查 libx264、AAC、ffmpeg/ffprobe 版本及可写磁盘；doctor 不通过则不渲染。T02 同时采用本包 schema 与语义规则。T03 相同输入连续运行计划 JSON 内容哈希一致（运行时间等非确定字段放报告，不放计划）。T04 先支持 1x/硬切/无音乐，后加音轨；不得先做复杂特效。T05 approve 不能由 render 自动触发，须用户明确命令。T06 操作指南必须标明素材权利与人工检查。

## 未来端到端接口（Claude 应实现）
在新仓库根目录运行；input/ 下实录与 markers.json 由用户提供，config/defaults.json 和 schemas/ 从本包复制。T06 应提供 markers 格式：`{"markers":[{"id":"k1","source_id":"s1","time_s":10,"priority":1,"origin":"human"}]}`；probe 输出 source_id=s1 的元数据。下面仅单源 MVP，扩展多源需显式清单，不扫描未知目录。

```bash
python -m montage.cli probe --input input/owned/session01.mp4 --asset-root input --source-id s1 --out work/source.json
python -m montage.cli plan --source work/source.json --markers input/markers.json --config config/defaults.json --out work/plan.json
python -m montage.cli render --plan work/plan.json --asset-root input --workdir work/run01 --out work/preview.mp4
python -m montage.cli inspect --plan work/plan.json --video work/preview.mp4 --out work/checks.json
# 用户看片后才可执行下一条；不得由脚本擅自批准
python -m montage.cli approve --plan work/plan.json --video work/preview.mp4 --config config/defaults.json --out work/approval.json
python -m montage.cli export --approval work/approval.json --out output/final.mp4
```

probe 保留 asset-root 相对路径 owned/session01.mp4；CLI 需要求 --asset-root 或明确 probe 阶段根目录=input，不能把绝对路径灌进计划。所有输出父目录可创建，但已存在文件应拒绝。验收：源文件哈希不变、输出可解码、锚点误差≤1帧、无漏标/重复、时长误差≤1帧、批准失效测试通过。inspect 的黑帧/静音只告警，不自动认定质量失败。审批文件不是发布授权。
