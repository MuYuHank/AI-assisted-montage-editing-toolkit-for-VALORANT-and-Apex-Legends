# 实际规格验证记录

时间：2026-11-07T10:54:14.963211+08:00（SGT）

实际环境：Python 3.13.5；用于目标应用的 Python 3.11 尚未运行。

实际执行：
```bash
uv pip install --python /workspace/kill-highlights-reference/.venv/bin/python jsonschema
/workspace/kill-highlights-reference/.venv/bin/python /workspace/validate_kill_spec.py
```

- Draft 2020-12 schema 自身合法；示例通过 jsonschema 4.26.0 验证。
- 全部 JSON 可解析。
- 示例 source 引用、区间、唯一锚点、连续输出、4.6s 总长与 k1=1.5s/k2=3.8s 映射通过；额外 1.25x 算术检查通过。短片低于目标是预期警告。
- 本地 Markdown 链接检查通过（含生成的 MANIFEST）。
- T01–T07 依赖无环；未来应用路径均为提议，不当作当前包文件校验。
- ZIP 成员哈希及归档 CRC 验证通过；包内无视频/音频/应用代码。

未执行：开发任务中的 pytest、CLI、合成素材、渲染、真实用户素材验收和音频分析。本包没有实现程序。MANIFEST 不哈希自身，避免递归；覆盖其他全部文件（含本记录）。验证脚本位于交付包外，是本次生成工具，不是未来产品。
